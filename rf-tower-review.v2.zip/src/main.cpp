
#include <iostream>
#include "commands/command_handlers.h"
#include "core/command.h"
#include "core/gpio.h"
#include "version.h"

void print_usage()

{
    std::cout
        << "Tower Home Automation Engine\n"
        << "Version " << TOWER_VERSION << "\n\n"
        << "Usage:\n"
        << "  tower version\n"
        << "  tower receive\n"
		<< "  tower monitor\n"
		<< "  tower service\n"
        << "  tower send\n"
        << "  tower learn\n"
        << "  tower learn-kernel\n"
        << "  tower replay\n"
        << "  tower config\n"
		<< "  tower sensor\n"
        << "  tower device\n"
        << "  tower command\n"
        << "  tower execute <device-id> <command-id>\n";
		
}

int main(int argc, char* argv[])
{
    if (argc == 1)
    {
        print_usage();
        return 0;
    }

    switch (parseCommand(argv[1]))
    {
        case Command::Version:
            return runVersionCommand();

        case Command::Receive:
            return runReceiveCommand();
			
        case Command::Monitor:
            return runMonitorCommand();
			
        case Command::Service:
            return runServiceCommand();

        case Command::Send:
            return runSendCommand(argc, argv);

        case Command::Learn:
            return runLearnCommand(argc, argv);
        case Command::Replay:
            return runReplayCommand(argc, argv);

        case Command::LearnKernel:
            return runLearnKernelCommand();

        case Command::Config:
            return runConfigCommand();
			
		case Command::Sensor:
            return runSensorCommand();

        case Command::Device:
            return runDeviceCommand(argc, argv);
			
        case Command::LogicalCommand:
            return runLogicalCommand(argc, argv);
			
        case Command::Execute:
            return runExecuteCommand(argc, argv);			

        default:
            std::cerr << "Unknown command\n\n";
            print_usage();
            return 1;
    }

    return 0;
}
